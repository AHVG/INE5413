# sim vou fazer os 2
# pelo menos deu vontade de fazer
class Prim:
    ...